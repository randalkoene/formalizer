var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 35.0,
      "background-opacity" : 1.0,
      "background-color" : "rgb(137,208,245)",
      "color" : "rgb(0,0,0)",
      "font-size" : 12,
      "border-opacity" : 1.0,
      "border-width" : 0.0,
      "width" : 75.0,
      "shape" : "roundrectangle",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-color" : "rgb(204,204,204)",
      "text-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "width" : 2.0,
      "opacity" : 1.0,
      "content" : "",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "source-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "line-color" : "rgb(132,132,132)",
      "source-arrow-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "color" : "rgb(0,0,0)",
      "target-arrow-shape" : "none"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]